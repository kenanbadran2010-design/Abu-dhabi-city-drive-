#!/usr/bin/env python3
"""Import an actual OSM .pbf/.osm file to Godot JSON. pip install osmium
No fictional street data is generated. Area chunks recommended for Android.
"""
import argparse,json,math,pathlib,sys
try: import osmium
except ImportError: sys.exit('Install importer dependency: pip install osmium')
PARSER=argparse.ArgumentParser()
PARSER.add_argument('input',help='OpenStreetMap .osm.pbf or .osm file (download from a licensed provider)')
PARSER.add_argument('--lat',type=float,default=24.4539,help='Origin latitude, default central Abu Dhabi')
PARSER.add_argument('--lon',type=float,default=54.3773,help='Origin longitude')
PARSER.add_argument('--radius-km',type=float,default=5.0,help='Import radius; start with 2-5 km for Android')
PARSER.add_argument('--output',default='data/roads.json')
args=PARSER.parse_args()
R=6378137.0
COS=math.cos(math.radians(args.lat))
def project(lat,lon): return [round(R*math.radians(lon-args.lon)*COS,2),round(-R*math.radians(lat-args.lat),2)]
def inside(lat,lon):
 x,z=project(lat,lon);return x*x+z*z <= (args.radius_km*1000)**2
ROAD_WIDTH={'motorway':16,'trunk':14,'primary':12,'secondary':10,'tertiary':9,'residential':7,'living_street':6,'service':5,'unclassified':7,'motorway_link':8,'trunk_link':8,'primary_link':7,'secondary_link':6}
POI_KEYS=('name','amenity','tourism','shop','leisure','historic')
class Collector(osmium.SimpleHandler):
 def __init__(self):
  super().__init__();self.nodes={};self.roads=[];self.buildings=[];self.poi=[]
 def node(self,n):
  if not n.location.valid():return
  if not inside(n.location.lat,n.location.lon):return
  if 'name' in n.tags and any(k in n.tags for k in POI_KEYS[1:]):
   x,z=project(n.location.lat,n.location.lon)
   self.poi.append({'name':n.tags['name'],'x':x,'z':z,'kind':next((n.tags[k] for k in POI_KEYS[1:] if k in n.tags),'place')})
 def way(self,w):
  coords=[]
  for n in w.nodes:
   if not n.location.valid():return
   coords.append((str(n.ref),n.location.lat,n.location.lon))
  if not coords or not any(inside(lat,lon) for _,lat,lon in coords):return
  highway=w.tags.get('highway')
  if highway in ROAD_WIDTH and len(coords)>=2:
   for nid,lat,lon in coords:self.nodes[nid]=project(lat,lon)
   self.roads.append({'nodes':[nid for nid,_,_ in coords], 'name':w.tags.get('name',''), 'width':ROAD_WIDTH[highway], 'oneway':w.tags.get('oneway')=='yes' or highway=='motorway', 'type':highway, 'maxspeed':w.tags.get('maxspeed','')})
  if 'building' in w.tags and len(coords)>=4 and coords[0][0]==coords[-1][0]:
   try: height=float(w.tags.get('height','').replace('m','').strip())
   except ValueError:
    try:height=float(w.tags.get('building:levels','3'))*3.4
    except ValueError:height=10.2
   self.buildings.append({'polygon':[project(lat,lon) for _,lat,lon in coords], 'height':min(250,max(3,height)), 'name':w.tags.get('name','')})
  if 'name' in w.tags and any(k in w.tags for k in POI_KEYS[1:]):
   lat=sum(c[1] for c in coords)/len(coords);lon=sum(c[2] for c in coords)/len(coords)
   x,z=project(lat,lon);self.poi.append({'name':w.tags['name'],'x':x,'z':z,'kind':'place'})
c=Collector();print('Reading real OSM geometry:',args.input,flush=True)
c.apply_file(args.input,locations=True)
out={'metadata':{'source':'OpenStreetMap contributors','license':'ODbL','origin_lat':args.lat,'origin_lon':args.lon,'radius_km':args.radius_km,'notes':'Imported real geometry. Building models are approximate blockouts. Not all signs/lanes included.'},'nodes':c.nodes,'roads':c.roads,'buildings':c.buildings,'poi':c.poi}
path=pathlib.Path(args.output);path.parent.mkdir(parents=True,exist_ok=True)
path.write_text(json.dumps(out,separators=(',',':')),encoding='utf-8')
print('Wrote',path,'nodes',len(c.nodes),'roads',len(c.roads),'buildings',len(c.buildings),'POIs',len(c.poi))
if not c.roads: print('WARNING: no roads in area. Choose a different origin or extract.')
