# Abu Dhabi City Drive — Godot 4, development build 0.2

**Native Godot project, not HTML, not an APK, and not a complete Abu Dhabi game.**

## What's new
- Fixed previous blank-screen behavior when `data/roads.json` is missing: a clearly labeled **fictional training circuit** and start menu appear instead.
- Touch steering, gas, brake, camera switching, speedometer, day/night and basic traffic systems are in source.
- Real OSM import pipeline is retained, but actual road data **is not bundled**.

## Open on Android
1. Extract ZIP with My Files.
2. In Godot 4 Android Editor, **Import** the `project.godot` in this folder.
3. Tap Play, then START DRIVING TEST.
4. If it fails, open Godot Debugger > Errors and share a screenshot.

## Real geographic data (requires computer or compatible Python environment)
Download a legal OpenStreetMap `.osm.pbf` or `.osm` extract. Install `osmium` (`pip install osmium`) and run:

`python tools/import_osm.py map.osm.pbf --lat 24.4539 --lon 54.3773 --radius-km 3 --output data/roads.json`

Godot then renders imported OSM road centerlines and approximate building blockouts. Real lane-level details, 3D facades, bridges, road signs and realistic traffic simulation are not implemented. Do not import the entire emirate as one scene on Android: streaming/tiling is needed.

**Map data attribution:** © OpenStreetMap contributors, ODbL: https://www.openstreetmap.org/copyright

## Android APK
This is source code, not an APK. An Android SDK/export configuration and device testing are required before an APK can be delivered. No Android runtime verification was possible in this environment.
