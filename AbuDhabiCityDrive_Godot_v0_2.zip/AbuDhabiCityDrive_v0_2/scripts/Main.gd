extends Node3D
# Native Godot runtime. All geometry comes from imported OSM data.
const MAP_PATH := "res://data/roads.json"
var graph: Dictionary = {}
var positions: Dictionary = {}
var poi: Array = []
var road_edges: Array = []
var car: CharacterBody3D
var car_speed := 0.0
var heading := 0.0
var throttle := false
var braking := false
var steer_left := false
var steer_right := false
var camera: Camera3D
var camera_mode := 0
var ui: Control
var speed_label: Label
var gps_label: Label
var mission_label: Label
var status_label: Label
var minimap: Control
var destination: String = ""
var route: Array = []
var npc_cars: Array = []
var traffic_enabled := true
var day_mode := true
var started := false
var map_loaded := false
var speed_limit := 110.0
var mission_count := 0

func _ready() -> void:
 _setup_world()
 _setup_ui()
 _load_map()

func _setup_world() -> void:
 var env := WorldEnvironment.new()
 var e := Environment.new()
 e.background_mode = Environment.BG_COLOR
 e.background_color = Color(0.60, 0.76, 0.91)
 e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
 e.ambient_light_color = Color(0.85,0.87,0.92)
 e.ambient_light_energy = 0.75
 env.environment = e
 add_child(env)
 var sun := DirectionalLight3D.new()
 sun.rotation_degrees = Vector3(-55, -25, 0)
 sun.light_energy = 1.2
 add_child(sun)
 car = CharacterBody3D.new()
 car.name = "PlayerCar"
 add_child(car)
 var body := _box(Vector3(2.0,0.7,4.2), Color(0.02,0.31,0.64))
 body.position.y = 1.1
 car.add_child(body)
 var cabin := _box(Vector3(1.65,0.65,2.0), Color(0.12,0.19,0.26))
 cabin.position = Vector3(0,1.75,-0.15)
 car.add_child(cabin)
 for x in [-0.95,0.95]:
  for z in [-1.35,1.35]:
   var wheel := _box(Vector3(0.33,0.65,0.7),Color(0.035,0.035,0.04))
   wheel.position = Vector3(x,0.64,z)
   car.add_child(wheel)
 camera = Camera3D.new()
 camera.current = true
 camera.fov = 73.0
 add_child(camera)

func _box(size: Vector3, color: Color) -> MeshInstance3D:
 var mi := MeshInstance3D.new()
 var mesh := BoxMesh.new()
 mesh.size = size
 mi.mesh = mesh
 var mat := StandardMaterial3D.new()
 mat.albedo_color = color
 mi.material_override = mat
 return mi

func _load_map() -> void:
 if not FileAccess.file_exists(MAP_PATH):
  _set_status("REAL MAP NOT INSTALLED — import an Abu Dhabi OSM extract first. See README.")
  return
 var parsed = JSON.parse_string(FileAccess.get_file_as_string(MAP_PATH))
 if not parsed is Dictionary or not parsed.has("nodes"):
  _set_status("Invalid map data. Re-run the importer.")
  return
 var map: Dictionary = parsed
 for key in map["nodes"]:
  var a: Array = map["nodes"][key]
  positions[str(key)] = Vector3(float(a[0]),0.0,float(a[1]))
  graph[str(key)] = []
 for road in map.get("roads",[]):
  var ids: Array = road.get("nodes",[])
  for i in range(ids.size()-1):
   var a := str(ids[i]); var b := str(ids[i+1])
   if not positions.has(a) or not positions.has(b): continue
   _road_segment(positions[a],positions[b],float(road.get("width",7.0)))
   var dist: float = positions[a].distance_to(positions[b])
   graph[a].append({"to":b,"cost":dist})
   if not road.get("oneway",false): graph[b].append({"to":a,"cost":dist})
   road_edges.append([a,b])
 for building in map.get("buildings",[]):
  _building(building)
 poi = map.get("poi",[])
 if positions.size() > 0:
  var first_id: String = str(positions.keys()[0])
  car.position = positions[first_id] + Vector3(0,0.12,0)
  if road_edges.size()>0:
   var first_edge: Array = road_edges[0]
   var v: Vector3 = positions[first_edge[1]] - positions[first_edge[0]]
   heading = atan2(-v.x,-v.z)
  map_loaded = true
  started = true
  _set_status("Real OSM roads loaded: %d nodes, %d segments, %d POIs" % [positions.size(),road_edges.size(),poi.size()])
  _spawn_traffic()
 else:
  _set_status("Map has no driveable roads.")

func _road_segment(a: Vector3,b: Vector3,width: float) -> void:
 var delta := b-a
 if delta.length() < 0.2: return
 var road := _box(Vector3(width,0.10,delta.length()),Color(0.14,0.16,0.18))
 road.position = (a+b)*0.5 + Vector3(0,0.025,0)
 road.rotation.y = atan2(-delta.x,-delta.z)
 add_child(road)
 # One dashed center marking per segment, where long enough.
 if delta.length()>12.0:
  var mark := _box(Vector3(0.13,0.012,min(2.8,delta.length()*0.20)),Color(0.91,0.85,0.61))
  mark.position = road.position + Vector3(0,0.065,0)
  mark.rotation.y = road.rotation.y
  add_child(mark)

func _building(info: Dictionary) -> void:
 var poly: Array = info.get("polygon",[])
 if poly.size()<3: return
 # OSM footprint bounding-box blockout, not a claim of photorealistic architecture.
 var minx := INF; var maxx := -INF; var minz := INF; var maxz := -INF
 for p in poly:
  minx = minf(minx,float(p[0])); maxx=maxf(maxx,float(p[0]))
  minz = minf(minz,float(p[1])); maxz=maxf(maxz,float(p[1]))
 var h: float = clampf(float(info.get("height",12.0)),3.0,160.0)
 if maxx-minx < 1.0 or maxz-minz < 1.0: return
 var b := _box(Vector3(maxx-minx,h,maxz-minz),Color(0.70,0.69,0.64))
 b.position = Vector3((minx+maxx)*0.5,h*0.5,(minz+maxz)*0.5)
 add_child(b)

func _spawn_traffic() -> void:
 if road_edges.size()==0: return
 for i in range(mini(22,road_edges.size())):
  var edge: Array = road_edges[(i*37)%road_edges.size()]
  var npc := _box(Vector3(1.8,0.8,3.6),Color(0.8,0.14+0.02*(i%5),0.09))
  var a: Vector3 = positions[edge[0]]; var b: Vector3 = positions[edge[1]]
  npc.position = a.lerp(b,0.3)+Vector3(0,0.65,0)
  npc.rotation.y = atan2(-(b-a).x,-(b-a).z)
  add_child(npc)
  npc_cars.append({"mesh":npc,"edge":edge,"progress":0.3,"speed":8.0+float(i%5)*1.7})

func _physics_process(delta: float) -> void:
 if not map_loaded: return
 var gas := throttle or Input.is_action_pressed("accelerate")
 var brake := braking or Input.is_action_pressed("brake")
 var turn := int(steer_right or Input.is_action_pressed("right"))-int(steer_left or Input.is_action_pressed("left"))
 var accel := 15.0 if gas else (-20.0 if brake else -6.0)
 car_speed = clampf(car_speed+accel*delta,-10.0,36.0)
 if absf(car_speed)<0.15 and not gas: car_speed=0.0
 heading += float(turn)*delta*0.95*clampf(absf(car_speed)/9.0,0.15,1.0)*signf(car_speed)
 var forward := Vector3(-sin(heading),0,-cos(heading))
 car.position += forward*car_speed*delta
 car.rotation.y = heading
 var offset := Vector3(0,5.4,11.0).rotated(Vector3.UP,heading)
 if camera_mode==1: offset=Vector3(0,2.5,0.6).rotated(Vector3.UP,heading)
 if camera_mode==2: offset=Vector3(0,17,2).rotated(Vector3.UP,heading)
 camera.position = camera.position.lerp(car.position+offset,minf(1.0,delta*6.0))
 camera.look_at(car.position+Vector3(0,1.0,0))
 speed_label.text="%03d km/h" % int(absf(car_speed)*3.6)
 _update_mission()
 if traffic_enabled: _update_traffic(delta)

func _update_traffic(delta:float) -> void:
 for npc in npc_cars:
  var edge: Array=npc["edge"]
  var a: Vector3=positions[edge[0]]; var b: Vector3=positions[edge[1]]
  var mesh: MeshInstance3D=npc["mesh"]
  if mesh.position.distance_to(car.position)<9.0: continue
  npc["progress"] += float(npc["speed"])*delta/maxf(1.0,a.distance_to(b))
  if npc["progress"]>=1.0:
   var options: Array=graph.get(edge[1],[])
   if options.is_empty(): npc["progress"]=0.0
   else:
    npc["edge"]=[edge[1],str(options[randi()%options.size()]["to"])]
    npc["progress"]=0.0
   edge=npc["edge"]
   a=positions[edge[0]];b=positions[edge[1]]
  mesh.position=a.lerp(b,float(npc["progress"]))+Vector3(0,0.65,0)
  mesh.rotation.y=atan2(-(b-a).x,-(b-a).z)

func _nearest_node(pos:Vector3) -> String:
 var best := ""; var dist := INF
 for id in positions:
  var d:float=positions[id].distance_squared_to(pos)
  if d<dist: dist=d;best=id
 return best

func _navigate_to(target:Vector3) -> void:
 if not map_loaded:return
 var start:=_nearest_node(car.position);var goal:=_nearest_node(target)
 var frontier: Array=[start]
 var distances: Dictionary={start:0.0};var previous: Dictionary={}
 # Dijkstra routing on imported OSM road graph (one-way restrictions respected).
 while not frontier.is_empty():
  var idx:=0
  for i in range(1,frontier.size()):
   if distances[frontier[i]]<distances[frontier[idx]]:idx=i
  var node: String=frontier.pop_at(idx)
  if node==goal:break
  for link in graph[node]:
   var nxt:String=link["to"]
   var cost:float=distances[node]+float(link["cost"])
   if cost<float(distances.get(nxt,INF)):
    distances[nxt]=cost;previous[nxt]=node
    if not frontier.has(nxt):frontier.append(nxt)
 route.clear()
 if start!=goal and not previous.has(goal):
  gps_label.text="GPS: no connected route";return
 var cursor:=goal
 route.push_front(positions[cursor])
 while cursor!=start and previous.has(cursor):
  cursor=previous[cursor]
  route.push_front(positions[cursor])
 gps_label.text="GPS route: %.1f km" % (float(distances.get(goal,0.0))/1000.0)

func _update_mission() -> void:
 if destination=="" or route.is_empty():return
 var end:Vector3=route.back()
 var remaining:=car.position.distance_to(end)
 mission_label.text="Destination: %s | %.0f m" % [destination,remaining]
 if remaining<24.0:
  mission_count+=1
  destination="";route.clear()
  mission_label.text="MISSION COMPLETE! Deliveries: %d" % mission_count

func _setup_ui() -> void:
 var layer:=CanvasLayer.new();add_child(layer)
 ui=Control.new();ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 layer.add_child(ui)
 var bg:=Color(0.06,0.10,0.15,0.80)
 _label("ABU DHABI CITY DRIVE  |  REAL ROAD EDITION",Vector2(20,12),24)
 speed_label=_label("000 km/h",Vector2(22,52),30)
 gps_label=_label("GPS: choose a destination",Vector2(22,93),19)
 mission_label=_label("MISSION: explore Abu Dhabi",Vector2(22,122),18)
 status_label=_label("Loading geographic data...",Vector2(20,165),17)
 status_label.add_theme_color_override("font_color",Color(1.0,0.8,0.34))
 _button("◀",Vector2(20,535),Vector2(105,120),func(v):steer_left=v)
 _button("▶",Vector2(135,535),Vector2(105,120),func(v):steer_right=v)
 _button("BRAKE",Vector2(1010,535),Vector2(105,120),func(v):braking=v)
 _button("GAS",Vector2(1125,535),Vector2(125,120),func(v):throttle=v)
 _tap("CAMERA",Vector2(1050,22),func():camera_mode=(camera_mode+1)%3)
 _tap("TRAFFIC",Vector2(1050,72),func():traffic_enabled=not traffic_enabled)
 _tap("DAY/NIGHT",Vector2(1050,122),func():_toggle_day())
 _tap("GPS / MISSIONS",Vector2(20,210),func():_show_missions())

func _label(t:String,p:Vector2,size:int) -> Label:
 var l:=Label.new();l.text=t;l.position=p
 l.add_theme_font_size_override("font_size",size)
 l.add_theme_color_override("font_color",Color.WHITE)
 l.add_theme_color_override("font_shadow_color",Color.BLACK)
 l.add_theme_constant_override("shadow_offset_x",2)
 l.add_theme_constant_override("shadow_offset_y",2)
 ui.add_child(l);return l

func _button(t:String,p:Vector2,s:Vector2,callback:Callable) -> void:
 var b:=Button.new();b.text=t;b.position=p;b.size=s
 b.add_theme_font_size_override("font_size",25)
 ui.add_child(b)
 b.button_down.connect(func():callback.call(true))
 b.button_up.connect(func():callback.call(false))

func _tap(t:String,p:Vector2,callback:Callable) -> void:
 var b:=Button.new();b.text=t;b.position=p;b.size=Vector2(200,43)
 ui.add_child(b);b.pressed.connect(callback)

func _show_missions() -> void:
 var panel:=PanelContainer.new();panel.position=Vector2(340,90);panel.custom_minimum_size=Vector2(540,500)
 ui.add_child(panel)
 var v:=VBoxContainer.new();panel.add_child(v)
 var title:=Label.new();title.text="GPS DESTINATIONS — REAL OSM PLACES";v.add_child(title)
 var close:=Button.new();close.text="CLOSE";v.add_child(close);close.pressed.connect(func():panel.queue_free())
 if poi.is_empty():
  var no:=Label.new();no.text="No POIs imported. Download OSM data and run tools/import_osm.py.";v.add_child(no)
 for entry in poi.slice(0,18):
  var btn:=Button.new();btn.text=str(entry.get("name","Unnamed location"))
  v.add_child(btn)
  btn.pressed.connect(func():
   destination=str(entry.get("name","Location"))
   _navigate_to(Vector3(float(entry["x"]),0,float(entry["z"])))
   panel.queue_free())

func _toggle_day() -> void:
 day_mode=not day_mode
 var env:WorldEnvironment=get_node("WorldEnvironment")
 env.environment.background_color=Color(0.60,0.76,0.91) if day_mode else Color(0.025,0.035,0.08)

func _set_status(s:String) -> void:
 if status_label:status_label.text=s
